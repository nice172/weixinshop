// pages/My.mod/Receivingaddress/Receivingaddress.js
var http = require('../../request');
var city = require('../../city');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    address: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  addNewaddressBtn: function(){
    wx.navigateTo({
      url: '../addticket/index',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var app = getApp()
    var page = this;
    http.send({
      url: app.config.ApiUrl + '?act=ticket_list',
      data: {},
      method: "POST",
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      success: function (res) {
        if (res.data.code == 20001) {
          wx.showToast({
            title: '请先登录用户',
            icon: 'none',
            mask: true,
            success: function (res) { },
            fail: function (res) { },
            complete: function (res) { },
          });
          setTimeout(function () {
            wx.navigateTo({
              url: '../Login/Login',
              success: function (res) { },
              fail: function (res) { },
              complete: function (res) { },
            });
          }, 1500);
          return;
        }
        for (var key in res.data) {
          var consignee = res.data[key];
          var address = city.findName(consignee.province, consignee.city, consignee.district)
          consignee.addressStr = address.address + " " + consignee.company_address;
        }
        page.setData({
          address: res.data
        });
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  Btn_SetDefault: function (e) {
    var index = e.currentTarget.dataset.index;
    this.SetDefault(this.data.address[index]);
  },
  SetDefault: function (city) {
    var app = getApp();
    var page = this;
    if (city["is_default"] == '1'){
      return;
    }
    wx.showLoading({
      title: '设置中...',
      mask: true,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    });
    setTimeout(function () {
      wx.hideLoading();
    }, 30000);
    city["is_default"] = 1;
    city["submit"] = "确认修改";
    http.send({
      url: app.config.ApiUrl +'?act=set_ticket',
      data: city,
      method: "POST",
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      success: function (res) {
        wx.hideLoading();
        wx.showToast({
          title: res.data.content,
          icon: 'none',
          duration: 2000
        });
        page.onShow();
      }
    });

  },
  Btn_DeleteAddress: function (e) {
    this.DeletAddress(e.currentTarget.dataset.id);
  },
  DeletAddress: function (id) {
    var app = getApp()
    var page = this;
    http.send({
      url: app.config.ApiUrl +'?act=delete_ticket',
      data: {
        id: id
      },
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      success: function (res) {
        wx.showToast({
          title: res.data.content,
          icon: 'none',
          duration: 2000
        });
        page.onShow();
      }
    })

  },
  editAddress: function (e) {
    var app = getApp();
    wx.setStorageSync('ticket_item', e.currentTarget.dataset.item);
    wx.navigateTo({
      url: '../addticket/index?type=edit'
    });
  }
})