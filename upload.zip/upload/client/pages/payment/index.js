var http = require('../../request');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    allPrice: "0.00",
    pay_price: '0.00',
    num: 0,
    isChoseAll: false,
    carts: [],
    in_load:false,
    consignee: {},
    shipping_free: '0.00',
    total:{},
    shipping_list:[],
    shipping_selected_id:0,
    need_ban: 0,
    ban_text: '',
    disabled: true,
    need_inv: 0,
    disabled1: true,
    inv_content_list: [],
    inv_content_list_index: 0,
    inv_type_list:[],
    inv_type_list_index: 0,
    ticket_list:{},
    ticket_list_index:0,
    postscript:'',
    _type: 'default'
  },

  address_click: function(){
    wx.navigateTo({
      url: '../My.mod/Receivingaddress/Receivingaddress',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    });
  },

  postscript: function(e){
      this.setData({
        postscript: e.detail.value
      });
  },
  ban_text: function (e) {
    this.setData({
      ban_text: e.detail.value
    });
  },
  checkboxChange: function(e){
    var need_ban = e.detail.value;
    if(need_ban.length == 1){
      this.setData({
        need_ban: 1,
        disabled: false
      });
    }else{
      this.setData({
        need_ban: 0,
        disabled: true
      });
    }
  },

  checkboxChange1: function (e) {
    var need_inv = e.detail.value;
    if (need_inv.length == 1) {
      this.setData({
        need_inv: 1,
        disabled1: false
      });
    } else {
      this.setData({
        need_inv: 0,
        disabled1: true
      });
    }
  },

  inv_typeChange: function(e){
    this.setData({
      inv_type_list_index: e.detail.value
    });
  },
  inv_contentChange: function(e){
    this.setData({
      inv_content_list_index: e.detail.value
    });
  },
  ticket_listChange: function(e){
    this.setData({
      ticket_list_index: e.detail.value
    });
  },
  managerTitcket: function(e){
    wx.navigateTo({
      url: '../ticket/index',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    });
  },

  radioChange: function(e){
    var shipping_id = e.detail.value;
    var shipping_list = this.data.shipping_list;
    for (var i in shipping_list){
      if (shipping_list[i]['shipping_id'] == shipping_id){
          shipping_list[i]['checked'] = true;
          this.setData({
            shipping_selected_id: shipping_id
          });
      }
    }
    this.setData({
      shipping_list: shipping_list
    });
    console.log(e);
    this.load();
  },

  payment: function (e) {
    if (this.data.carts.length <= 0) {
      wx.showToast({
        title: '您的购物车中没商品！',
        icon: 'none',
        mask: true,
        success: function (res) { },
        fail: function (res) { },
        complete: function (res) { },
      });
      return;
    }
    if (this.data.need_inv){
      if (this.data.ticket_list.length == 0){
        wx.showToast({
          title: '请选择发票抬头',
          icon: 'none',
          mask: true
        })
        return;
      }
      if (this.data.ticket_list[this.data.ticket_list_index]['ticket_id'] == 0){
        wx.showToast({
          title: '请选择发票抬头',
          icon: 'none',
          mask: true
        })
        return;
      }
    }
    var selectArr = [];
    for (var i in this.data.carts) {
      var items = this.data.carts[i].items;
      for (var j in items) {
        selectArr.push(items[j]['goods_id']);
      }
    }
    if (selectArr.length <= 0) {
      wx.showToast({
        title: '请至少选择一个商品',
        icon: 'none',
        mask: true
      });
      return;
    }
    wx.showLoading({
      title: '正在提交订单中',
      mask: true,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    });

    var shipping_selected_id = this.data.shipping_selected_id;
    if (shipping_selected_id == 0){
      var shipping_list = this.data.shipping_list;
      for (var i in shipping_list) {
        if(i == 0){
          shipping_selected_id = shipping_list[i]['shipping_id'];
          break;
        }
      }
    }

    var app = getApp();
    var page = this;
    wx.login({
      success: function (res) {
        if (res.code) {
          http.send({
            url: app.config.ApiUrl + '?act=payment&type=' + page.data._type+'&code=' + res.code,
            data: {
              goodsids: selectArr,
              shipping_id: shipping_selected_id,
              postscript: page.data.postscript,
              need_inv: page.data.need_inv,
              inv_type: page.data.need_inv == 1 ? page.data.inv_type_list[page.data.inv_type_list_index] : '',
              inv_payee: page.data.need_inv == 1 ? page.data.ticket_list[page.data.ticket_list_index]['ticket_id'] : 0,
              inv_content: page.data.need_inv == 1 ? page.data.inv_content_list[page.data.inv_content_list_index] : '',
              ban_text: page.data.ban_text,
              need_ban: page.data.need_ban
            },
            method: 'POST',
            header: {
              "content-type": "application/x-www-form-urlencoded"
            },
            success: function (response) {
              wx.hideLoading();

              if (response.data.code == 1) {
                var order = response.data.order;
                wx.requestPayment({
                  timeStamp: order.timeStamp,
                  nonceStr: order.nonceStr,
                  package: order.package,
                  signType: order.signType,
                  paySign: order.paySign,
                  success: function (res) {
                    if (res.errMsg == 'requestPayment:ok') {
                      wx.removeStorageSync('goodsid');
                      wx.showToast({
                        title: '支付成功',
                        icon: 'none',
                        mask: true
                      });
                      setTimeout(function () {
                        wx.redirectTo({
                          url: '../My.mod/Fullorder/Fullorder?index=2',
                          success: function (res) { },
                          fail: function (res) { },
                          complete: function (res) { },
                        })
                      }, 1500);
                    }
                  },
                  fail: function (res) {
                    wx.removeStorageSync('goodsid');
                    if (res.errMsg == 'requestPayment:fail cancel') {
                      wx.showToast({
                        title: '用户取消支付',
                        icon: 'none',
                        mask: true
                      })
                    } else {
                      wx.showToast({
                        title: '支付失败',
                        icon: 'none',
                        mask: true
                      })
                    }
                    setTimeout(function () {
                      wx.redirectTo({
                        url: '../My.mod/Fullorder/Fullorder',
                        success: function (res) { },
                        fail: function (res) { },
                        complete: function (res) { },
                      })
                    }, 1500);
                  },
                  complete: function (res) {
                    console.log(res);
                  },
                });
                if (page.data._type == 'quick_order') {
                  page.insertParams(response.data.pay_id);
                }

              } else if (response.data.code == '20001') {

                wx.showToast({
                  title: '请先登录用户',
                  icon: 'none'
                });
                setTimeout(() => {
                  wx.redirectTo({
                    url: '../Login/Login',
                  });
                }, 1500);

              } else {
                wx.showToast({
                  title: response.data.msg,
                  icon: 'none',
                  mask: true
                });
                if(response.data.code == '-9'){
                  if (page.data._type == 'quick_order') {
                    page.insertParams(response.data.pay_id);
                  }
                  setTimeout(function () {
                    wx.redirectTo({
                      url: '../My.mod/Fullorder/Fullorder?index=1',
                      success: function (res) { },
                      fail: function (res) { },
                      complete: function (res) { },
                    })
                  }, 1500);
                }
              }
            }
          });
        }

      },
      fail: function (res) { },
      complete: function (res) { },
    });
  },

  insertParams: function (order_id){
    var app = getApp();
    var page = this;
    var FormData = wx.getStorageSync('FormData');
    if (FormData){
      FormData.order_id = order_id;
    http.send({
      url: app.config.ApiUrl + "?act=quick&type=params",
      method: 'POST',
      data: FormData,
      success: function (response) {
        wx.removeStorageSync('FormData');
      }
    });
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //this.load();
    this.setData({
      _type: options.type
    });
  },

  load: function(){
    wx.showLoading({
      title: '加载中...',
      mask: true
    });
    var app = getApp();
    var page = this;
    var goodsids = wx.getStorageSync('goodsid');
    http.send({
      url: app.config.ApiUrl + '?act=checkout&type='+this.data._type, //仅为示例，并非真实的接口地址
      method: 'POST',
      data: { goodsids: goodsids },
      header: {
        'content-type': 'application/json', // 默认值,
        'cookie': wx.getStorageSync("sessionid")
      },
      success: function (res) {
        page.setData({
          in_load: true
        });
        wx.hideLoading();
        wx.setStorageSync("sessionid", res.header["Set-Cookie"]);
        if (res.data.code == 1) {
          var data = res.data.data;
          var goods_list = data.goods_list;
          var shops = {};
          for (var index in goods_list) {
            var item = goods_list[index];
            var shopname = item.supplier;
            var shopary = shops[shopname];
            if (shopary == null) {
              shopary = [];
              shops[shopname] = shopary;
            }
            item.goods_img = app.config.ImageRoot + item.goods_img;
            shopary.push(item);
          }
          var prarmary = [];
          for (var name in shops) {
            var shop = {
              shopname: name,
              items: shops[name]
            }
            prarmary.push(shop);
          }
          page.setData({
            shipping_list: data.shipping_list,
            inv_content_list: data.inv_content_list,
            inv_type_list: data.inv_type_list,
            ticket_list: data.ticket_list,
            total: data.total,
            consignee: data.consignee,
            carts: prarmary
          });
        } else {
          wx.showToast({
            title: res.data.msg,
            icon: 'none',
            mask: true
          });
        }
      }
    });
  },

  goBtn: function () {
    wx.switchTab({
      url: '../../shop/shop'
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.load();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    wx.showShareMenu({
      withShareTicket: true
    });
    var parent_id = wx.getStorageSync('parent_id');
    if (parent_id == '') {
      return {
        title: '商城',
        path: '/pages/shop/shop'
      };
    } else {
      return {
        title: '商城',
        path: '/pages/shop/shop?userid=' + parent_id
      };
    }
  }
})