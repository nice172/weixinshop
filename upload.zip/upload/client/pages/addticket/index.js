// pages/My.mod/Receivingaddress/editaddress/EditReivingAddress.js
var http = require('../../request');
var city = require('../../city');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ticket_id: "",
    ticket_name:"",
    company_name:'',
    company_sn:'',
    company_phone:'',
    company_bank:'',
    company_bankcard:'',
    company_address: "", //详细地址 必填
    is_default: '',
    _type: '',
    province: "20", //省
    city: "233", //城市
    district: "2415", //区
    country: "1",
    ShowCitys: [city.shop_province_list, city.city_list[20], city.district_list[233]],
    CityText: ["广东省", "深圳市", "宝安区"],
    options: [18, 2, 3],
    oncity: 20
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var app = getApp()
    if (options["type"] != null) {
      var cache = wx.getStorageSync('ticket_item');
      var data = {};
      for (var key in this.data) {
        if (cache[key] != null) {
          data[key] = cache[key];
        }
      }
      var incity = city.findName(cache.province, cache.city, cache.district);
      data["ShowCitys"] = [city.shop_province_list, city.city_list[incity.province_id], city.district_list[incity.cityid_id]];
      data['CityText'] = [incity.province, incity.cityid, incity.district];
      data['_type'] = 'edit';
      this.setData(data);
      var province_index = 0;
      for (var i in city.shop_province_list) {
        if (city.shop_province_list[i]['region_id'] == incity.province_id) {
          province_index = i;
          break;
        }
      }
      var city_index = 0;
      for (var i in city.city_list[incity.province_id]) {
        if (city.city_list[incity.province_id][i]['region_id'] == incity.cityid_id) {
          city_index = i;
          break;
        }
      }
      var area_index = 0;
      for (var i in city.district_list[incity.cityid_id]) {
        if (city.district_list[incity.cityid_id][i]['region_id'] == incity.district_id) {
          area_index = i;
          break;
        }
      }
      this.setData({
        options: [province_index, city_index, area_index],
        oncity: incity.province_id
      });
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  add_new_address: function () {
    var app = getApp()
    var page = this;

    if (this.data.ticket_name == '') {
      wx.showToast({
        title: '请输入发票名称',
        icon: 'none',
        mask: true
      });
      return;
    }
    if (this.data.company_name == '') {
      wx.showToast({
        title: '请输入发票抬头',
        icon: 'none',
        mask: true
      });
      return;
    }
    if (this.data.company_sn == '') {
      wx.showToast({
        title: '请输入纳税人识别号',
        icon: 'none',
        mask: true
      });
      return;
    }
    if (this.data.company_address == '') {
      wx.showToast({
        title: '请输入详细地址',
        icon: 'none',
        mask: true
      });
      return;
    }
    if (this.data.company_phone == '') {
      wx.showToast({
        title: '请输入联系电话',
        icon: 'none',
        mask: true
      });
      return;
    }
    if (this.data.company_bank == '') {
      wx.showToast({
        title: '请输入开户行名称',
        icon: 'none',
        mask: true
      });
      return;
    }
    if (this.data.company_bankcard == '') {
      wx.showToast({
        title: '请输入开户行卡号',
        icon: 'none',
        mask: true
      });
      return;
    }
    wx.showLoading({
      title: '保存中...',
      mask: true,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    });
    setTimeout(function () {
      wx.hideLoading();
    }, 30000);
    http.send({
      url: app.config.ApiUrl +'?act=act_edit_ticket',
      data: this.data,
      method: "POST",
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      success: function (res) {
        wx.hideLoading();
        wx.showToast({
          title: res.data.msg,
          icon: 'none',
          duration: 2000,
          success: function () {
            if (res.data.code == "1") {
              setTimeout(() => {
                wx.navigateBack();
              },2000);
            }
          }
        })
      }
    })
  },
  bindRegionChange: function (e) {
    var options = [];
    var cityvalue = [];
    var province = null;
    var cityid = null;
    var district = null;
    if (e.detail.value[0] == null) {
      e.detail.value[0] = 0;
    }
    if (e.detail.value[1] == null) {
      e.detail.value[1] = 0;
    }
    if (e.detail.value[2] == null) {
      e.detail.value[2] = 0;
    }
    for (var index in e.detail.value) {
      console.log(this.data.ShowCitys[index][e.detail.value[index]])
      var address_id = 0
      if (this.data.ShowCitys[index] == null || e.detail.value[index] == null || this.data.ShowCitys[index][e.detail.value[index]] == null || this.data.ShowCitys[index][e.detail.value[index]]["region_name"] == null) {
        cityvalue[index] = "";
      } else {
        cityvalue[index] = this.data.ShowCitys[index][e.detail.value[index]]["region_name"];
        options[index] = e.detail.value[index];
        address_id = this.data.ShowCitys[index][e.detail.value[index]].region_id;
      }
      if (index == 0) {
        province = address_id
      }
      if (index == 1) {
        cityid = address_id
      }
      if (index == 2) {
        if (address_id == 0) {
          var current = city.district_list[cityid][0];
          address_id = current.region_id;
          cityvalue[index] = current.region_name;
          options[index] = 0;
        }
        district = address_id;
      }
    }
    this.setData({
      options: options,
      CityText: cityvalue,
      province: province,
      district: district,
      city: cityid
    })
    //var addressids = city.findID(e.detail.value[0], e.detail.value[1], e.detail.value[2]);
    //console.log(addressids)
  },
  onchange: function (e) {
    console.log(e)
    var value = e.detail.value
    var name = e.target.dataset.name
    var data = {};
    data[name] = value
    this.setData(data)
  },
  bindcolumnchange: function (e) {
    console.log(e)
    if (e.detail.column == 0) {
      this.setData({
        ShowCitys: [city.shop_province_list, city.city_list[city.shop_province_list[e.detail.value].region_id], city.district_list[city.city_list[city.shop_province_list[e.detail.value].region_id][0].region_id]],
        oncity: city.shop_province_list[e.detail.value].region_id
      })
    }
    if (e.detail.column == 1) {
      this.setData({
        ShowCitys: [city.shop_province_list, city.city_list[this.data.oncity], city.district_list[city.city_list[this.data.oncity][e.detail.value].region_id]]
      })
    }
  }
})