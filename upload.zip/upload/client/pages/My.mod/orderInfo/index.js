// pages/My.mod/orderInfo/index.js
var http = require('../../../request.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    order_id:0,
    order:{},
    goods_list:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var order_id = options.order_id;
      this.setData({
        order_id: options.order_id
      });
    this.loadData(order_id);
  },

  loadData: function (order_id){
    wx.showLoading({
      title: '加载中...',
      mask: true
    });
    setTimeout(function () {
      wx.hideLoading();
    }, 30000);
    var app = getApp();
    var _this = this;
    http.send({
      url: app.config.ApiUrl + '?act=order_detail&order_id=' + order_id,
      success: function (res) {
        wx.hideLoading();
        if (res.data.code == 1) {
          var goods_list = res.data.data.goods_list;
          var shops = {};
          for (var i in goods_list) {
            var item = goods_list[i];
            var shopname = item.shopname;
            var shopary = shops[shopname];
            if (shopary == null) {
              shopary = [];
              shops[shopname] = shopary;
            }
            item.goods_img = app.config.ImageRoot + item.goods_img;
            shopary.push(item);
          }
          var prarmary = [];
          for (var name in shops) {
            var shop = {
              shopname: name,
              items: shops[name]
            }
            prarmary.push(shop);
          }

          _this.setData({
            order: res.data.data.order,
            goods_list: prarmary
          });

        }

      }

    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },

  payment: function (event) {
    wx.showLoading({
      title: '请稍后...',
      mask: true
    });
    setTimeout(function () {
      wx.hideLoading();
    }, 30000);
    var app = getApp();
    var _this = this;
    var order_id = event.target.dataset.order_id;
    var index = event.target.dataset.index;
    wx.login({
      success: function (res) {

        if (res.code) {
          http.send({
            url: app.config.ApiUrl + '?act=order_pay&code=' + res.code + '&order_id=' + order_id,
            method: 'GET',
            success: function (response) {
              wx.hideLoading();
              if (response.data.code == 1) {
                var order = response.data.order;
                wx.requestPayment({
                  timeStamp: order.timeStamp,
                  nonceStr: order.nonceStr,
                  package: order.package,
                  signType: order.signType,
                  paySign: order.paySign,
                  success: function (res) {
                    if (res.errMsg == 'requestPayment:ok') {
                      wx.showToast({
                        title: '支付成功',
                        icon: 'none',
                        mask: true
                      });
                      _this.loadData(order_id);
                    }
                  },
                  fail: function (res) {
                    if (res.errMsg == 'requestPayment:fail cancel') {
                      wx.showToast({
                        title: '用户取消支付',
                        icon: 'none',
                        mask: true
                      })
                    } else {
                      wx.showToast({
                        title: '支付失败',
                        icon: 'none',
                        mask: true
                      })
                    }

                  },
                  complete: function (res) {
                    console.log(res);
                  },
                })


              } else {
                wx.showToast({
                  title: response.data.msg,
                  icon: 'none',
                  mask: true
                });
              }
            }
          });
        }

      },
      fail: function (res) { },
      complete: function (res) { },
    })

  },

  cancel: function (event) {
    var app = getApp();
    var _this = this;
    var order_id = event.target.dataset.order_id;
    var index = event.target.dataset.index;
    wx.showModal({
      title: '提示',
      content: '确认取消吗?',
      success: function (res) {
        if (res.confirm) {
          wx.showLoading({
            title: '取消中...',
            mask: true,
            success: function (res) { },
            fail: function (res) { },
            complete: function (res) { },
          });
          setTimeout(() => { wx.hideLoading() }, 30000);
          http.send({

            url: app.config.ApiUrl + '?act=cancelorder&order_id=' + order_id,
            success: function (response) {

              wx.hideLoading();
              wx.showToast({
                title: response.data.msg,
                icon: 'none',
                mask: true,
                success: function (res) { },
                fail: function (res) { },
                complete: function (res) { },
              });
              if (response.data.code == 1) {
                _this.loadData(order_id);
              }

            }

          });

        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },

  confirm: function (event) {
    var app = getApp();
    var _this = this;
    var order_id = event.target.dataset.order_id;
    var index = event.target.dataset.index;
    wx.showModal({
      title: '提示',
      content: '确认收到货物了吗?',
      success: function (res) {
        if (res.confirm) {
          wx.showLoading({
            title: '确认中...',
            mask: true,
            success: function (res) { },
            fail: function (res) { },
            complete: function (res) { },
          });
          setTimeout(() => { wx.hideLoading() }, 30000);
          http.send({

            url: app.config.ApiUrl + '?act=confirm&order_id=' + order_id,
            success: function (response) {

              wx.hideLoading();
              wx.showToast({
                title: response.data.msg,
                icon: 'none',
                mask: true,
                success: function (res) { },
                fail: function (res) { },
                complete: function (res) { },
              });
              if (response.data.code == 1) {
                _this.loadData(order_id);
              }

            }

          });

        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },

  refund: function (event) {
    var app = getApp();
    var _this = this;
    var order_id = event.target.dataset.order_id;
    var index = event.target.dataset.index;
    wx.showModal({
      title: '提示',
      content: '确认退货吗?',
      success: function (res) {
        if (res.confirm) {
          wx.showLoading({
            title: '退货中...',
            mask: true,
            success: function (res) { },
            fail: function (res) { },
            complete: function (res) { },
          });
          setTimeout(() => { wx.hideLoading() }, 30000);
          http.send({

            url: app.config.ApiUrl + '?act=refundgoods&order_id=' + order_id,
            success: function (response) {

              wx.hideLoading();
              wx.showToast({
                title: response.data.msg,
                icon: 'none',
                mask: true,
                success: function (res) { },
                fail: function (res) { },
                complete: function (res) { },
              });
              if (response.data.code == 1) {
                _this.loadData(order_id);
              }

            }

          });

        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  }

})